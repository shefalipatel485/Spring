package com.java.Spring_MVC;

public interface UserService {
	void register(User user);
	 User validateUser(User login);
}
