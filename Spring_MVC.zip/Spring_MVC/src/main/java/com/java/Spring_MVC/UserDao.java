package com.java.Spring_MVC;

public interface UserDao {
	void register(User user);
	 User validateUser(User login);
}
