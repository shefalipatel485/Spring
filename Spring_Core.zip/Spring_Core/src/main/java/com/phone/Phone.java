package com.phone;

public class Phone {

	
	private int phonum;
	private String phonemodel;
	public int getPhonum() {
		return phonum;
	}
	public void setPhonum(int phonum) {
		this.phonum = phonum;
	}
	public String getPhonemodel() {
		return phonemodel;
	}
	
	public void setPhonemodel(String phonemodel) {
		this.phonemodel = phonemodel;
	}
	@Override
	public String toString() {
		return "Phone [phonum=" + phonum + ", phonemodel=" + phonemodel + "]";
	}
}
