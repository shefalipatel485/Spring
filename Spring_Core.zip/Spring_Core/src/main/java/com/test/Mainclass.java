package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.person.Person;

public class Mainclass {
public static void main(String[] args) {
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("bean.xml");
	Person p=(Person)ap.getBean("Person");
	p.getphone();
	
}
}
