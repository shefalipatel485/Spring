package com.person;

import com.phone.Phone;

public class Person {

	private Phone phone;
	private String name;
	private int id;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Phone getPhone() {
		return phone;
	}

	public void setPhone(Phone phone) {
		this.phone = phone;
	}
	public void getphone() {
		System.out.println(getId()+" "+getName());
		System.out.println(phone.toString());
	}
	
	
}
