package com.student;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mainclass {
public static void main(String[] args) {
	ApplicationContext ap=new ClassPathXmlApplicationContext("bean.xml");
	 Student s=(Student)  ap.getBean("student");
	System.out.println( s.toString());

}
}
