package com.Spring_mvc.Spring_MVC_jdbc;

public interface UserService {
public void register(USer user);
USer validateUser(USer login);
}
