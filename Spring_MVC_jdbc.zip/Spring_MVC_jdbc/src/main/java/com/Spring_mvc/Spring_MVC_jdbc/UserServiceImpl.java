package com.Spring_mvc.Spring_MVC_jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("UserService")
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao dao;
	
	public void register(USer user) {
		// TODO Auto-generated method stub
		dao.register(user);
	}

	public USer validateUser(USer login) {
		// TODO Auto-generated method stub
		return dao.validateUser(login);
	}

}
