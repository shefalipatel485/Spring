package com.Spring_mvc.Spring_MVC_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;





public class UserImple implements UserDao {
	@Autowired
	  DataSource datasource;
	  @Autowired
	  JdbcTemplate jdbcTemplate;
	public void register(USer user) {
		// TODO Auto-generated method stub
	String sql = "insert into spring_jdbc(username,password) values(?,?)";
	jdbcTemplate.update(sql, new Object[] {user.getName(),user.getPass()});
	
	
	}
	public USer validateUser(USer login) {
		// TODO Auto-generated method stub
		String sql = "select * from spring_jdbc where username='" + login.getName() + "' and password='" + login.getPass()
	    + "'";
		
	List<USer> user=	jdbcTemplate.query(sql, new UserMapper());
		
		return user.size() > 0 ? user.get(0) : null;
	}

	
	
	class UserMapper implements RowMapper<USer>
	{

		public USer mapRow(ResultSet rs, int arg1) throws SQLException {
			// TODO Auto-generated method stub
			  USer user = new USer();
			    user.setName(rs.getString("username"));
			    user.setPass(rs.getString("password"));
			return user;
		}
		
	}
	
	
}
