package com.Spring_mvc.Spring_MVC_jdbc;



public interface UserDao {
public void register(USer user);
USer validateUser(USer login);
}
