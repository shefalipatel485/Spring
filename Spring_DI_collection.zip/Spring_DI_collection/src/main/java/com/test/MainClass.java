package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext a=new ClassPathXmlApplicationContext("beans.xml");
		Customer c=(Customer) a.getBean("customer");
		c.displayCustomer();
		System.out.println("List: "+c.getLists());
		System.out.println("Maps : "+c.getMaps());
	}
}
