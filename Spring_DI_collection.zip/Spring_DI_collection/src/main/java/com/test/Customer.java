package com.test;

import java.util.List;
import java.util.Map;

public class Customer {

	private List<Object> lists;
	private Map<Object, Object> maps;

	public Map<Object, Object> getMaps() {
		return maps;
	}

	public void setMaps(Map<Object, Object> maps) {
		this.maps = maps;
	}

	public List<Object> getLists() {
		return lists;
	}

	public void setLists(List<Object> lists) {
		this.lists = lists;
	}
	public String toString()
	{
		return "Customer : "+lists+" Maps : "+maps;
	}
	public void displayCustomer()
	{
		System.out.println("Customer List :"+lists);
	}
}
